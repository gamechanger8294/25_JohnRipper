# ------------ PWCRACKER2.PY ------------ #
# ALLOWS USER TO ENTER THE FILES TO READ FROM
# BEEFED UP ERROR HANDLING FROM PWCRACKER1.PY

# ------------ IMPORTS ------------ #
import hashlib		# NEEDED TO DO THE HASH WORK
import os		# USED FOR FILE ERROR HANDLING

# ----------------------------------- #
# ------------ FUNCTIONS ------------ #
# ----------------------------------- #

# ------------ PROMPTS USER TO CONTINUE ------------ #
def cont():
	cont = raw_input("Continue?[Y/n]: ")					# PROMPTS USER CONTINUE?
	while (cont != "Y" and cont != "y" and cont != "N" and cont != "n"):	# LOOPS UNTIL USER ENTER "Y' OR "N"
		print "ERROR: Invalid Input. Try Again . . ."			# LETS USER KNOW THEY ENTERED INVALID INPUT
		cont = raw_input("Continue?[Y/n]: ")				# PROMPTS USER CONTINUE AGAIN

	if cont == "Y" or cont == "y":						# USER'S "Y" OPTION			
		print "\n"							# PRINTS NEWLINE TO KEEP TERMINAL "PRETTY"
		return True							# RETURNS TRUE IF USER WANTS TO CONTINUE

	else:									# USER'S "N" OPTION
		print "\nQuitting . . . "					# LETS USER KNOW PROGRAM IS QUITtING
		quit()								# QUITS THE PROGRAM

# ------------ SEARCH LOOP ------------ #
def searchlist(Hash, num, wordlist):						# TAKES THE HASH WE'RE SEARCHING FOR, NUM, AND THE WORDLIST AS PARAMETERS
	for line in open(wordlist, "r"):					# WILL READ IN ONE LINE OF PASSWORD FILE AND SAVE IT TO LINE, UNTIL eof
		line = line.replace("\n", "")					# REMOVES NEWLINE CHARACTERS

		num = num + 1							# INCREMENTS NUM (LINE NUMBER COUNT)

		if hashlib.md5(line).hexdigest() == Hash:			# COMPARES THE HASH TO THE PASSWORD FROM FILE, IF EQUAL RUNS CODE BELOW
			print "WOO! Got one on line " + str(num) + ". The password is: " + line 
			if cont() == True:					# CALLS THE CONTINUE FUNCTION, IF TRUE CONTINUES OTHERWISE QUITS
				return						# RETURNS TO MAIN AND MOVES TO NEXT HASH

	print "Searched " + str(num) + " Passwords. No Match Found."		# PRINTS THIS IF IT GETS THROUGH THE WHOLE LOOP W\O FINDING A PASSWORD
	if cont() == True:							# CALLS THE CONTINUE FUNCTION, IF TRUE CONTINUES OTHERWISE QUITS
		return								# RETURNS TO MAIN AND MOVES TO NEXT HASH

# ------------ CHECK IF FILE EXISTS ------------ #
def file_exists(file):							# MAKES SURE FILE EXISTS, TAKES A FILE AS A PARAMETER
	if os.path.isfile("./" + file) == False:			# CHECKS TO SEE IF FILE EXISTS
		print "ERROR: File (" + file + ") Doesn't Exist."	# LETS THE USER KNOW WHAT THE ERROR IS
		return False						# RETURNS FALSE IF FILE DOESN'T EXISTS
	return True							# RETURNS TRUE IF FILE EXISTS

# ------------ CHECK IF FILE IS EMPTY ------------ #
def file_empty(file):							# MAKES SURE FILE ISN'T EMPTY, TAKES A FILE AS A PARAMETER
	if os.path.getsize("./" + file) == 0:				# CHECKS TO MAKES SURE FILE ISN'T EMPTY
		print "ERROR: File (" + file + ") Is Empty."		# LETS THE USER KNOW WHAT THE ERROR IS
		return False						# RETURNS FALSE IF FILE IS EMPTY
	return True							# RETURNS TRUE IF FILE ISN'T EMPTY

# ------------ ERROR PRINTING ------------ #
def error(hashlist, wordlist):				# ERROR WILL TEST IF BITH FILES ARE VALID, TAKES BOTH FILES AS PARAMETERS
	print "\n"					# PRINTS NEWLINE TO KEEP TERMINAL "PRETTY"

	check1 = file_exists(hashlist)			# TESTS IF HASHLIST EXISTS, SETS CHECK1 TO TRUE OR FALSE
	check2 = file_exists(wordlist)			# TESTS IF WORDLIST EXISTS, SETS CHECK2 TO TRUE OR FALS

	if check1 == True:				# IF HASHLIST EXISTS
		check1 = file_empty(hashlist)		# CHECKS IF THE FILE IS EMPTY AND SETS CHECK1 TO TRUE OR FALSE
	
	if check2 == True:				# IF WORDLIST EXISTS
		check2 = file_empty(wordlist)		# CHECKS IF THE FILE IS EMPTY AND SETS CHECK2 TO TRUE OR FALSE
	
	if check1 == False or check2 == False:		# IF CHECK1 OR CHECK2 ARE FALSE (ONE OR BOTH OF THE FILES ARE EMPTY OR DOESNT EXIST)
		print"\nQuitting . . ."			# LETS USER KNOW PROGRAM IS QUITTING
		quit()					# QUITS PROGRAM

	return						# RETURNS ONLY IF ALL FILE ENTRYS ARE VALID

# -------------------------------- #
# ------------ "MAIN" ------------ #
# -------------------------------- #

def main():
	hashlist = raw_input("Enter Your Hashed List File: ") 		# PROMPTS USER FOR THE HASHED lIST FILE
	hashlist = hashlist.replace("\n", "")				# REMOVES THE NEWLINE CHARACTER
	wordlist = raw_input("Enter Your Password List File: ")		# PROMPTS USER FOR THE PASSWORD LIST FILE
	wordlist = wordlist.replace("\n", "")				# REMOVES THE NEWLINE CHARACTER

	error(hashlist, wordlist)					# CALLS THE ERROR FUNCTION TO MAKE SURE BOTH FILES ARE VALID ENTRIES

	print "Running . . .\n"						# LETS USER KNOW FILE WER VALID AND PROGRAM IS CONTINUING

	for Hash in open(hashlist, "r"):				# READS IN ONE FILE FROM THE HASHLIST FILE AND SAVES IT TO HASH UNTIL EOF
		Hash = Hash.replace("\n", "")				# REMOVES THE NEWLINE CHARACTER FROM THE HASH
		print "Hash: " + Hash					# PRINTS CURRENT HASH
		num = 0							# MAKES SURE NUM IS ALWAYS AT ZERO BEFORE SEARCHING AGAIN
		searchlist(Hash, num, wordlist)				# CALLS SEARCHLIST AND ATTEMPTS TO FIND THE PASSWORD FOR THE HASH

	print "End Of File, Quitting . . ."				# LETS THE USER KNOW THAT PROGRAM REACHED THE END OF THE HASH LIST FILE
	quit()								# QUITS PROGRAM

# ------------ MAIN CALL ------------ #
main()		# CALLS MAIN

