#!/usr/bin/python


from Tkinter import *				# USED FOR THE GUI
from tkMessageBox import *			# ALLOWS FOR POPUPS
import hashlib					# NEEDED FOR HASH WORK
import os					# USED WITH FILE ERROR HANDLING
import csv					# NEEDED FOR FILE EXPLORER
from tkFileDialog import askopenfilename	# NEEDED FOR FILE EXPLORER
import sys

# ------------------------------------------------------------------------------------------------ #
# --------------------------------------- SETS UP THE GUI ---------------------------------------- #
# ------------------------------------------------------------------------------------------------ #

class Main:

	# ------------ SETS UP MAIN GUI LOOP ------------ #
	root = Tk()						# INITIALIZES GUI AS ROOT					
	root.title("Password Cracker GUI")			# SETS THE TITLE OF THE GUI
	root.resizable(width=0, height=0)			# MAKES IT SO WINDOW CANNOT BE RESIZED

	# ------------ INITIALIZES CLASS VARIABLES ------------ #
	Run_Open = IntVar()					# HELPS KEEP TRACK OF RUN BUTTON BEING PRESSED
	Run_Open.set(0)

	Hash_Label_Text = StringVar()				# USED TO CHANGE TEXT FOR HASH ENTRY (EITHER HASH LIST OR HASH)
	Hash_Label_Text.set("Hash List: ")

	Password_Found = BooleanVar()				# KEEPS TRACK OF WHETHER OR NOT A PASSWORD WAS FOUND
	Password_Found.set(False)

	Status_Line = StringVar()				# USED TO DISPLAY THE STATUS OF PROGRAM ON THE STATUS BAR
	Status_Line.set("Program Status Bar...")

	Hash_Result = StringVar()				# USED TO DISPLAY THE HASH WHEN SEARCHING
	Hash_Result.set("-")

	Result_ALine = StringVar()				# USED TO PRINT THE RESULT 1ST LINE
	Result_ALine.set("-")
	Result_BLine = StringVar()				# USED TO PRINT RESULT 2ND LINE IF NEED BE
	Result_BLine.set("")

	Browse_Line = StringVar()				# USED TO CONTROLL LABEL FOR HASH ENTRY BUTTON (DISAPPEARS ON SINGLE HASH ENTRY)
	Browse_Line.set("Browse...")

	write = IntVar()					# USED TO KEEP TRACK OF WHETHER OR NOT USER WANTS TO WRITE TO FILE
	write.set(0)

	Open = IntVar()						# USED TO KEEP TRACK OF OPENING HASH LIST FILE
	Open.set(0)				

	def __init__(self):

		# ------------ HASH OPTIONS SECTION ------------ #
		optionsframe = LabelFrame(text=" Options ", labelanchor=NW)					# CREATES HASH OPTIONS SECTION
		optionsframe.grid(row=0, column=0, padx=5, pady=5, sticky=N)					# TELLS THE PROGRAM WHERE TO PLACE SECTION

		self.Single_Hash_Option = Radiobutton(optionsframe, text="Single Hash", value=0, height=1)	# CREATES THE SINGLE HASH OPTION
		self.Single_Hash_Option.grid(row=0, column=0, sticky=W, pady=3)					# TELLS WHERE TO PLACE IT
		self.Single_Hash_Option.bind('<Button-1>', self.Single_Hash_Options)	# BINDS IT TO THE FUNCTION SINGLE_HASH_OPTIONS ON LEFT CLICK
	
		self.Brute_Force_Option = Radiobutton(optionsframe, text="Brute Force Attack", value=0, height=1)	# CREATES THE BRUTE-FORCE ATTACK OPTION
		self.Brute_Force_Option.grid(row=1, column=0, sticky=W, pady=3)					# TELLS WHERE TO PLACE IT
		self.Brute_Force_Option.bind('<Button-1>', self.brute_force)	# BINDS IT TO THE FUNCTION BRUTE-FORCE ATTACK OPTION ON LEFT CLICK

		self.Hash_List_Option = Radiobutton(optionsframe, text=" From List ", value=1, height=1)	# CREATES THE HASH LIST OPTION
		self.Hash_List_Option.grid(row=2, column=0, sticky=W, pady=2)					# TELLS WHERE TO PLACE IT
		self.Hash_List_Option.bind('<Button-1>', self.Hash_List_Options)	# BINDS IT TO THE FUNCTION HASH_LIST_OPTIONS ON LEFT CLICK

		self.Write_File = Checkbutton(optionsframe, variable=self.write, text="Write to File", height=1)	# CREATES WRITE FILE CHECKBOX
		self.Write_File.grid(row=3, column=0, sticky=W, pady=3)							# WHERE TO PLACE IT
		self.Write_File.bind('<Button-1>', self.Write)				# BINDS IT TO THE FUNCTION WRITE ON LEFT CLICK

		# ------------ USER INPUT SECTION ------------ #		# ---- EVERYTHING HERE ON OUT IS SIMILAR, IF NOT IT IS NOTED ---- #
		inputs = LabelFrame(text=" User Input ", labelanchor=NW)
		inputs.grid(row=0, column=1, padx=5, pady=5, sticky=N)
		
		self.Hash_Label = Label(inputs, textvariable=self.Hash_Label_Text)			# TEXT CHANGES BASED ON HASH OPTION SELECTED
		self.Hash_Label.grid(row=0, column=0, padx=5, pady=5)
		self.Hash_Entry = Entry(inputs, state=DISABLED)						# CREATES THE ENTRY BOX
		self.Hash_Entry.grid(row=0, column=1, padx=5, pady=5)

		self.Hash_Browse = Button(inputs, textvariable=self.Browse_Line, relief=FLAT, state=DISABLED)
		self.Hash_Browse.grid(row=0, column=2, padx=5, pady=5)
		self.Hash_Browse.bind('<Button-1>', self.Browse_Hash)

		Label(inputs, text="Password List: ").grid(row=1, column=0, padx=5, pady=5)
		self.Pass_Entry = Entry(inputs, state=DISABLED)						# CREATES THE ENTRY BOX
		self.Pass_Entry.grid(row=1, column=1, padx=5, pady=5)

		self.Pass_Browse = Button(inputs, text="Browse...", relief=FLAT, state=DISABLED)
		self.Pass_Browse.grid(row=1, column=2, padx=5, pady=5)
		self.Pass_Browse.bind('<Button-1>', self.Browse_Pass)

		# ------------ RESULT SECTION ------------ #
		results = LabelFrame(text=" Results ", labelanchor=NW)
		results.grid(row=1, columnspan=2)

		Label(results, text="Hash: ", width=60).pack(side=TOP, fill=X)
		Label(results, textvariable=self.Hash_Result).pack(side=TOP, fill=X)		# THIS LINE WILL CHANGE TO SHOW CURRENT HASH		
		Label(results, text="Result: ", width=60).pack(side=TOP, fill=X)
		Label(results, textvariable=self.Result_ALine).pack(side=TOP, fill=X)		# THIS LINE SHOWS THE RESULT
		Label(results, textvariable=self.Result_BLine).pack(side=TOP, fill=X)		# THIS LINE SHOWS RESULT IF PASSWORD FOUND (DISPLAYS PW)

		# ------------ RUN, CONTINUE, AND CLEAR BUTTONS ------------ #
		run = Frame()								# CREATES A SECTION WITHOUT A LABEL
		run.grid(row=2, columnspan=2, padx=5, pady=10)

		self.Run_Button = Button(run, text="Run", relief=FLAT, state=DISABLED)
		self.Run_Button.pack(side=LEFT)
		self.Run_Button.bind('<Button-1>', self.Run_Program)

		self.Cont_Button = Button(run, text="Continue")
		self.Cont_Button.pack(side=LEFT)
		self.Cont_Button.bind('<Button-1>', self.Continue)
		self.Cont_Button.config(relief = FLAT, state=DISABLED)				# BUTTON OPTIONS CHANGE WITH CONFIG
												# --- RELIEF OPTIONS EXPLAINED: --- #
		self.Clear_Button = Button(run, text="Clear", relief=FLAT, state=DISABLED)	# FLAT MEANS THE BUTTON DOESN'T POP OUT OF GUI
		self.Clear_Button.pack(side=LEFT)						# RAISED MEANS IT POPS OT AND ISN'T LEVEL WITH BACKGROUND
		self.Clear_Button.bind('<Button-1>', self.Clear_Inputs)				# --- STATE OPTIONS: --- #
												# DISABLED MEANS USER CANNOT CLICK
		# ------------ STATUS BAR SECTION ------------ #				# NORMAL MEANS USER CAN CLICK
		current = Frame()								# ACTIVE MEANS USER HAS CLICKED ON
		current.grid(row=3, columnspan=2, sticky=W+E)

		Label(current, textvariable=self.Status_Line, bd=1, relief=SUNKEN, bg="gray").pack(side=TOP, fill=X)

		# ------------ CALLS MAIN GUI LOOP ------------ #
		self.root.protocol("WM_DELETE_WINDOW", self.closing)	# "WM_DELETE_WINDOW" IS THE X IN THE TOP RIGHT CORNER OF GUI
		self.root.mainloop()	# STARTS RUNNING THE GUI LOOP

# ------------------------------------------------------------------------------------------------ #
# ------------------------------------------ FUNCTIONS ------------------------------------------- #
# ------------------------------------------------------------------------------------------------ #

	# ------------ WHEN RUN IS PRESSED ------------ #
	def Run_Program(self, event):			# TWO INPUTS, SELF BECAUSE UTS IN THE CLASS VARIABLE AND EVENT BECAUSE IT'LL RUN WHEN CLICKED
							# SELF DOESN'T GET PASSED IN BECAUSE OF HOW THE FUNCTION IS CALLED SELF.RUN_PROGRAM()
		global Pass_List				# GLOBALIZES PASS_LIST SO WE CAN ACCESS IT WHEREVER ITS NEEDED
		Pass_List = str(self.Pass_Entry.get())		# GETS THE ENTRY FROM THE ENTRY FIELD AND STORES IT AS A STRING IN PASS_LIST

		global Hash_List				# GLOBALIZES HASH_LIST SO WE CAN ACCESS IT WHEREVER ITS NEEDED
		Hash_List = str(self.Hash_Entry.get())		# GETS THE ENTRY FROM THE ENTRY FIELD AND STORES IT AS A STRING IN HASH_LIST

		global target					# GLOBALIZES TARGET, THIS WILL HOLD THE FILE TO WRITE TO IF SELECTED

		if self.File_Exists(Pass_List) == True and self.File_Empty(Pass_List) == True:	# ONLY RUNS IF PASS_LIST EXISTS AND ISNT EMPTY
			if self.Hash_Label.cget("text") == "Hash List: ":					# THIS MEANS WE'RE READING FROM HASH LIST
				if self.File_Exists(Hash_List) == True and self.File_Empty(Hash_List) == True:	# CHECKS VALIDITY OF HASH LIST FILE
					if self.write.get() == 1:			# CHECKS TO SEE IF USER WANTS TO WRITE TO FILE
						target = open("Results.txt", "wb")	# SETS TARGET EQUAL TO THE FILE TO WRITE TO 
						self.Run_Open.set(1)			# SETS VALUE TO 1 SO WE MAKE SURE TO CLOSE IT ON EXIT
						target.write("HASH LIST FILE: " + Hash_List + "\nPASSWORD FILE: " + Pass_List + "\n\n")	
						# WRITES FILE NAMES TO THE TARGET FILE 'RESULTS.TXT'
						self.Status_Line.set("Writing to File...")	# SETS THE STATSU LINE VARIABLE
					global text					# GLOBALIZES TEXT SO WE CAN USE IT WHEREVER
					text = open(Hash_List, "r")			# SETS TEXT EQUAL TO THE HASH_LIST FILE
					self.Open.set(1)				# SETS OPEN TO 1 SO WE REMEMBER TO CLOSE ON EXIT
					self.Status_Line.set("RUNNING: Hash List...")	
					self.Search_Hash_List()				# CALLS THE SEARCH HASH LIST FUNCTION

			else:								# THIS MEANS WE'RE LOOKING FOR A SINGLE HASH
				if self.Hash_Check(Hash_List) == True:			# MAKES SURE USER ENTERS VALID HASH 
					if self.write.get() == 1:
						target = open("Results.txt", "wb")	# SETS TARGET EQUAL TO THE OPEN FILE TO WRITE TO
						self.Run_Open.set(1)			# SETS VALUE TO 1 SO WE REMEMBER TO CLOSE IT ON EXIT
					self.Status_Line.set("RUNNING: Single Hash...")
					self.Search_Single_Hash()			# CALLS SEARCH SINGLE HASH LOOP
					
	# ------------ SINGLE HASH SEARCH LOOP ------------ #
	def Search_Single_Hash(self):

		self.Lock_Buttons()						# LOCKS MOST BUTTONS SO USER CAN'T CLICK ANYTHING WHILE RUNNING
		self.Password_Found.set(False)					# SETS TO FALSE, SO IT WILL ALWAYS START ON FALSE WHEN RECALLED
		HashIn = Hash_List.replace("\n", "")				# REMOVES THE NEWLINE CHARACTER FROM HASH AND SETS IT EQUAL TO HashIn
		self.Hash_Result.set(HashIn)					# UPDATES THE HASH RESULT SECTION T DISPLAY CURREENT HASH
		num = 0								# MAKES SURE NUM IS ALWAYS AT 0 BEFORE RUNNING LOOP

		if self.write.get() == 1:					# IF WRITE OPTION IS ACTIVE
			target.write("Hash: " + HashIn + "\n")			# WRITES THE HASH TO THE FILE

		for line in open(Pass_List, "r"):				# OPENS THE PASSWORD FILE TO SEARCH THROUGH, READS ONE LINE IN UNTIL EOF
			line = line.replace("\n", "")				# REMOVES THE NEWLINE CHARACTER FROM THE PASSWORD
			num = num + 1						# INCREMENTS THE NUM COUNT
			self.Status_Line.set("TESTING (" + str(num) +"): " + line)	# UPDATES THE STATUS BAR WITH CURRENT PROGRESS

			try:						
            			self.root.update()				# WILL TRY TO UPDATE THE ROOT, SO THE STATUS BAR EMAINS UPDATED

        		except TclError:					# STOPS ON ERROR 
            			return

			if hashlib.md5(line).hexdigest() == HashIn:		# COMPARES CURRENT HASH TO THE PASSWORD LINE, IF TRUE
				if self.write.get() == 1:
					target.write("PASSWORD: " + line + "\n\n")	# WRITES PASSWORD TO FILE

				self.Result_ALine.set("WOO! Got one on line " + str(num))	# SETS THE RESULT LINE
				self.Result_BLine.set("The password is: " + line)		# SETS THE RESULT LINE
				self.Status_Line.set("PASSWORD FOUND! Waiting...")		# UPDATES STATUS BAR
				self.Password_Found.set(True)					# UPDATES PASSWORD FOUND VARIABLE
				break						# BREAKS TO END THE FOR LOOP

		if self.Password_Found.get() == False:				# IF IT GETS HERE THE PASSWORD WASN'T FOUND AND THE WHOLE FILE WAS SEARCHED
			if self.write.get() == 1:
				target.write("NO PASSWORD FOUND\n\n")		# WRITE RESULT TO FILE

			self.Result_ALine.set("No Password Found")		# UPDATES RESULT LINE 1
			self.Result_BLine.set("")
			self.Status_Line.set("END OF FILE! NO PASSWORD FOUND...")	# UPDATES STATUS BAR

		self.Cont_Button.config(relief = RAISED, state=NORMAL)		# ACTIVATES THE CONTINUE BUTTON
        	self.Wait()             # GOES TO WAIT FUNCTION TO WAIT FOR USER BUTTON CLICK
        	
# ------------ HASHLIST SEARCH LOOP ------------ #
	def Search_Hash_List(self):

		self.Password_Found.set(False)					# SETS THE PASSWORD FOUND FILE TO FALSE, MAKES SURE IT STARTS HERE
		self.Lock_Buttons()						# LOCKS MOST BUTTONS DURING RUN
		HashIn = text.readline().replace("\n", "")			# READS IN ONE LINE FROM THE HASH LIST AND REPLACES NEWLINE CHARACTER

		if HashIn == "":						# MEANS WE REAHCED EOF
			self.Status_Line.set("END OF HASH LIST FILE! Waiting...")	# UPDATES STATUS BAR TO LET USER KNOW
			self.Result_ALine.set("-")					# sETS RESULT LINE 1 TO DEFAULT
			self.Result_BLine.set("")					# SETS RESULT LINE 2 TO DEFAULT
			self.Hash_Result.set("-")					# SETS HASH RESULT LINE TO DEFAULT

			self.Hash_List_Option.config(state = NORMAL)			# OPENS UP HASH LIST OPTION SELECTION BUTTON
			self.Single_Hash_Option.config(state = NORMAL)			# OPENS UP SINGLE HASH OPTION SELECTION BUTTON
			self.Cont_Button.config(relief = FLAT, state=DISABLED)		# DISABLES THE CONTINUE BUTTON
			self.Run_Button.config(relief = RAISED, state = NORMAL)		# ENABLED THE RUN BUTTON
			self.Hash_Entry.config(state = NORMAL)				# ENABLES THE HASH ENTRY 
			self.Hash_Entry.delete(0, "end")				# REMOVES CURRENT ENTRY AND SETS IT TO EMPTY
			self.Pass_Entry.config(state = NORMAL)				# ENABLES THE PASSWORD LISTS ENTRY
			self.Pass_Entry.delete(0, "end")				# REMOVES CURRENT ENTRY AND SETS IT TO EMPTY
			self.Hash_Browse.config(state = NORMAL, relief = RAISED)	# LETS THE USER USE THE BROWSE BUTTONS
			self.Pass_Browse.config(state = NORMAL, relief = RAISED)
			self.Write_File.config(state = NORMAL)				# ENABLES THE WRITE CHECK BOX AGAIN
			if self.write.get() == 1:
				target.close()						# CLOSES THE TARGET FILE
			self.Wait()							# CALLS THE WAIT FUNCTION

		else:							# REACHES THIS IF IT READS IN A HASH
			self.Hash_Result.set(HashIn)			# UODATES THE HASH IN THE RESULT SECTION

			if self.write.get() == 1:
				target.write("HASH: " + HashIn + "\n")	# WRITES THE HASH TO FILE 

			num = 0						# MAKES SURE NUM IS AT 0 BEFORE RUNNING THE SEARCH LOOP
	
			for line in open(Pass_List, "r"):		# READS LINE FROM PASSWORD FILE AND STORES IN LINE
				line = line.replace("\n", "")		# REMOVES THE NEWLINE CHARACTER
				num = num + 1				# INCREMENTS THE LINE COUNT
				self.Status_Line.set("TESTING (" + str(num) +"): " + line)	# UPDATES THE STATUS BAR

				try:
            				self.root.update()		# CONTINUES TO UPDATE GUI

        			except TclError:			# STOPS IF ERROR
            				return

				if hashlib.md5(line).hexdigest() == HashIn:	# IF THE HASH MATCHES THE LINE FROM PASSWORD FILE
					if self.write.get() == 1:
						target.write("PASSWORD: " + line + "\n\n")	# WRITES RESULTS TO TARGET

					self.Result_ALine.set("WOO! Got one on line " + str(num))	# UPDATES RESULT LINE 1
					self.Result_BLine.set("The password is: " + line)		# UPDATES RESULT LINE 2
					self.Status_Line.set("PASSWORD FOUND! Waiting...")		# UPDATES STATUS BAR
					self.Password_Found.set(True)			# UPDATES THE PASSWORD FOUND VARIABLE
					break					# BREAKS THE FOR LOOP

			if self.Password_Found.get() == False:		# GETS HERE IF IT GOES THROUGH THE WHOLE PASSWORD FILE WITHOUT FINDING A MATCH
				if self.write.get() == 1:
					target.write("NO PASSWORD FOUND\n\n")	# WRITES RESULT TO FILE

				self.Result_ALine.set("No Password Found")	# SETS RESULT LINE 1
				self.Result_BLine.set("")
				self.Status_Line.set("END OF FILE! NO PASSWORD FOUND...")	# UPDATES STATUS BAR

			self.Cont_Button.config(relief = RAISED, state=NORMAL)	# ENALBES THE CONTINUE BUTTON
			self.Wait()                     #CALLS THE WAIT FUNCTION
			
			
# ------------ BRUTEFORCE ATTACK FUNCTION ------------ #
	def brute_force(self):
                
                self.Password_Found.set(False)					# SETS THE PASSWORD FOUND FILE TO FALSE, MAKES SURE IT STARTS HERE
		self.Lock_Buttons()						# LOCKS MOST BUTTONS DURING RUN
		HashIn = text.readline().replace("\n", "")			# READS IN ONE LINE FROM THE HASH LIST AND REPLACES NEWLINE CHARACTER

		self.Status_Line.set("THE GUI IS BLOCKED PLEASE UPDATE THROUGH TERMINAL")	# UPDATES STATUS BAR
		
                password = input("pass:")
                #idea = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","1","2","3","4","5","6","7","8","9"," "]
                #THE IDEA ABOVE IS THE FULL A-Z, 0-9 (takes ages)
                password = input("pass:")
                idea = ["a","b","c","d"]
                awnser = [""] *6
                var = 0
                var1 = 0
                var2 = 0
                var3 = 0
                char = 0

                while awnser != password:
                    awnser = idea[var]
                    print(awnser)
                    if var != len(idea):
                        var += 1
                    if var == len(idea):
                        var = 0
                        while awnser != password:
                            awnser = idea[var]+idea[var1]
                            print(awnser)
                            if var != len(idea):
                                var += 1
                            if var == len(idea):
                                if var1 != len(idea):
                                    var = 0
                                    var1 += 1
                                if var1 == len(idea):
                                    var = 0
                                    var1 = 0
                                    while awnser != password:
                                        awnser = idea[var]+idea[var1]+idea[var2]
                                        print(awnser)
                                        if var != len(idea):
                                            var += 1
                                        if var == len(idea):
                                            if var1 != len(idea):
                                                var = 0
                                                var1 += 1
                                            if var1 == len(idea):
                                                if var2 != len(idea):
                                                    var = 0
                                                    var1 = 0
                                                    var2 += 1
                                                if var2 == len(idea):
                                                    var = 0
                                                    var1 = 0
                                                    var2 = 0
                                                    while awnser != password:
                                                        awnser = idea[var]+idea[var1]+idea[var2]+idea[var3]
                                                        print(awnser)
                                                        if var != len(idea):
                                                            var += 1
                                                        if var == len(idea):
                                                            if var1 != len(idea):
                                                                var = 0
                                                                var1 += 1
                                                            if var1 == len(idea):
                                                                if var2 != len(idea):
                                                                    var = 0
                                                                    var1 = 0
                                                                    var2 += 1
                                                                if var2 == len(idea):
                                                                    print("==============================================")
                                                                    print("Password too long or characters not in string!")
                                                                    print("==============================================")
                                                                    break

                print("==================")
                print("")
                input("Password = "+awnser)



# ------------ SETS UP SINGLE HASH OPTIONS ------------ #
	def Single_Hash_Options(self, event):

		self.Status_Line.set("LOADING: Single Hash Options...")		# UPDATES STATUS BAR
		self.Hash_Label_Text.set("Hash: ")				# UPDATES HASH ENTRY LABEL
		self.Browse_Line.set("")					# REMOVES BROWSE BUTTON TEXT
		self.Hash_Browse.config(relief = FLAT, state = DISABLED)	# DISABLES THE BROWSE BUTTON FOR HASH ENTRY
		self.Hash_Entry.config(state=NORMAL)				# ENABLES SINGLE HASH ENTRY FIELD
		self.Pass_Browse.config(relief = RAISED, state = NORMAL)	# ENABLES PASSWORD LIST FILE BROWSE BUTTON
		self.Pass_Entry.config(state=NORMAL)				# ENABLES PASSWORD FILE ENTRY FIELD
		self.Run_Button.config(relief=RAISED, state=NORMAL)		# ENABLES RUN BUTTON
		self.Clear_Button.config(relief=RAISED, state=NORMAL)		# ENABLES CLEAR BUTTON

# ------------ SETS UP HASH LIST OPTIONS ------------ #
	def Hash_List_Options(self, event):

		self.Status_Line.set("LOADING: Hash List Options...")		# UPDATES THE STATUS BAR
		self.Hash_Label_Text.set("Hash List: ")				# UODATES HASH ENTRY LABEL
		self.Browse_Line.set("Browse...")				# ENABLES TEXT ON THE HASH BROWSE BUTTON
		self.Hash_Browse.config(relief = RAISED, state = NORMAL)	# ALLOWS USER TO CLICK THE HASH BROWSE BUTTON
		self.Hash_Entry.config(state=NORMAL)				# ENABLES THE HASH LIST FILE ENTRY FIELD
		self.Pass_Browse.config(relief = RAISED, state = NORMAL)	# ENABLES PASSWORD LIST FILE BROWSE BUTTON
		self.Pass_Entry.config(state=NORMAL)				# ENABLES PASSWORD FILE ENTRY FIELD
		self.Run_Button.config(relief=RAISED, state=NORMAL)		# ENALBES THE RUN BUTTON
		self.Clear_Button.config(relief=RAISED, state=NORMAL)		# ENABLES THE CLEAR BUTTON

# ------------ SETS UP WRITE TO FILE OPTIONS ------------ #
	def Write(self, event):

		if self.write.get() == 0:						# SETS UP TO WRITE TO FILE WILL CHANGE WRITE VARIABLE TO 1
			self.Status_Line.set("Writing to file 'Results.txt'...")	# LETS USER KNOW THE SELECTION THEY'VE MADE
			showerror("WARNING!", "WARNING: If 'Results.txt' exists it will be overwritten.") 
			# WARNING MESSAGE POP UPS TO LET USER KNOW FLE WILL BE OVERWRITTEN

		else:									# NOT GOING TO WRITE TO FILE
			self.Status_Line.set("Not Writing to file...")			# LETS USER KNOW SLECTION IN STATUS BAR

	# ------------ CONTINUES AFTER A BREAK ------------ #
	def Continue(self, event):
	
		self.Password_Found.set(False)					# MAKES SURE THE PASSWORD FOUND VARIABLE IS RESET TO FALSE

		if self.Hash_Label.cget("text") == "Hash List: ":		# OPTIONS IF SEARCHING WITH HASH LIST
			self.Result_ALine.set("-")				# RESETS RESULT LINE
			self.Result_BLine.set("")				# RESETS RESULT LINE
			self.Cont_Button.config(relief = FLAT, state=DISABLED)	# DISABLES THE CONTINUE BUTTON SO IT CANT BE PRESSED DURING RUN
			self.Search_Hash_List()					# CALLS THE SEARCH HASH LIST LOOP

		else:								# OPTIONS IF SEARCHING SINGLE HASH
			self.Status_Line.set("Enter A New Hash...")		# UPDATES STATUS BAR 
			self.Hash_Result.set("-")				# RESETS THE HASH RESULT LINE
			self.Result_ALine.set("-")				# RESETS THE RESULT LINE
			self.Result_BLine.set("")				# RESETS THE RESULT LINE
			self.Cont_Button.config(relief = FLAT, state=DISABLED)	# DISABLES THE CONTINUE BUTTON
			self.Hash_Entry.config(state = NORMAL)			# ENABLES THE HASH ENTRY FIELD
			self.Hash_Entry.delete(0, "end")			# REMOVES THE CURRENT HASH SO USER CAN TYPE NEW HASH RIGHT AWAY
			self.Pass_Entry.config(state = NORMAL)			
			# ENABLES PASSWORD FILE ENTRY, DOESN'T DELETE SO THEY DON'T HAVE TO RETYPE IF THEY PLAN ON USING THE SAME FILE
			self.Hash_Browse.config(state = DISABLED, relief = FLAT)# DISABLES THE HASH BROWSE BUTTON
			self.Pass_Browse.config(state = NORMAL, relief = RAISED)# ENABLES THE PASSWORD FLE BROWSE BUTTON
			self.Run_Button.config(relief = RAISED, state = NORMAL)	# ENABLES THE RUN BUTTON
		
	# ------------ CLEARS INPUTS ------------ #
	def Clear_Inputs(self, event):

		self.Status_Line.set("Clearing . . .")			# LETS USER KNOW PROGRAM CLEARING

		self.Cont_Button.config(relief = FLAT, state = DISABLED)# DISABLES THE CONTINUE BUTTON
		self.Hash_List_Option.config(state = NORMAL)		# ENABLES THE HASH LIST SELECTION
		self.Single_Hash_Option.config(state = NORMAL)		# ENABLES THE SINGLE HASH SELECTION
		self.Run_Button.config(relief = RAISED, state = NORMAL)	# ENABLES THE RUN BUTTON
		self.Hash_Entry.config(state = NORMAL)			# ENABLES THE HASH ENTRY FIELD
		self.Pass_Entry.config(state = NORMAL)			# ENABLES THE PASSWORD FILE ENTRY FIELD
		self.Hash_Entry.delete(0, "end")			# REMOVES WHATEVERS THERE RIGHT NOW
		self.Pass_Entry.delete(0, "end")			# REMOVES WHATEVERS THERE RIGHT NOW
		self.Hash_Browse.config(state = NORMAL, relief = RAISED)# ENABLES BOTH BROWSE BUTTONS
		self.Pass_Browse.config(state = NORMAL, relief = RAISED)
		self.Write_File.config(state = NORMAL)			# ENABLES THE WRITE TO FILE CHECKBOX

		if self.Hash_Label.cget("text") == "Hash: ":		# IF CURRENTLY SEARCHING SINGLE HASH
			self.Hash_Browse.config(state = DISABLED, relief = FLAT)	# DISABLES THE HASH BROWSE BUTTON

		self.Hash_Result.set("-")		# RESETS THE RESULT LINES
		self.Result_ALine.set("-")
		self.Result_BLine.set("")

	# ------------ ALLOWS USER TO BROWSE FOR PASSWORD FILE ------------ #
	def Browse_Pass(self, event):

		self.Status_Line.set("Browsing for Password List File...")	# UPDATES STATUS
		Tk().withdraw() 						# ALLOWS FOR NEW WINDOW
		Pass_List = askopenfilename()					# OPEN FILE BROWSER AND SAVE SELECTED FILE IN PASS LIST

		self.Pass_Entry.delete(0, "end")				# REMOVES WHATEVERS IN ENTRY FIELD
		self.Pass_Entry.insert(0, Pass_List)				# INSERTS THE NEW FILE pATH

	# ------------ ALLOWS USER TO BROWSE FOR HASH LIST FILE ------------ #
	def Browse_Hash(self, event):

		self.Status_Line.set("Browsing for Hash List File...")		# UPDATES STATUS
		Tk().withdraw()							# ALLOWS FOR NEW WINDOW
		HashIn = askopenfilename()					# OPENS FILE BROWSER AND SAVES SLECTED FILE IN HASHiIN

		self.Hash_Entry.delete(0, "end")				# REMOVES WHATEVERS IN THE ENTRY FIELD
		self.Hash_Entry.insert(0, HashIn)				# INSERTS THE NEW FILE PATH
	
	# ------------ TEST FOR VALID HASH ------------ #
	def Hash_Check(self, Hash): 

		if len(Hash) != 32:						# MAKES SURE HASH IS 32 BITS
			showerror("ERROR!", "ERROR: Invalid Hash.")		# ERROR POPUP IF IT IS NOT
			self.Status_Line.set("ERROR! FIX TO CONTINUE...")	# UPDATES STATUS
			self.Wait()						# CALLS WAIT FUNCTION

		else:
			return True

	# ------------ CHECKS THAT FILE EXISTS ------------ #
	def File_Exists(self, file):

		if os.path.isfile(file) == False:						# CHECKS TO MAKES SURE FILE EXISTS
			showerror( "ERROR!","ERROR: File (" + file + ") Doesn't Exist.")	# IF FALSE SHOWS ERROR IN POPUP
			self.Status_Line.set("ERROR! FIX TO CONTINUE...")			# UPDATES STATUS
			self.Wait()								# CALLS WWAIT FUNCTION
		else:
			return True

	# ------------ CHECKS THAT FILE ISN'T EMPTY ------------ #
	def File_Empty(self, file):

		if os.path.getsize(file) == 0:						# CHECKS TO MAKE SURE FILE ISN'T EMPTY
			showerror("ERROR!","ERROR: File (" + file + ") Is Empty.")	# IF FALSE SHOWS ERROR IN POPUP
			self.Status_Line.set("ERROR! FIX TO CONTINUE...")		# UPDATES STATUS
			self.Wait()							# CALLS WAIT FUNCTION
		else:
			return True

	# ------------ LOCKS BUTTONS ON RUN ------------ #
	def Lock_Buttons(self):
		self.Hash_List_Option.config(state = DISABLED)
		self.Single_Hash_Option.config(state = DISABLED)
		self.Clear_Button.config(relief = FLAT, state = DISABLED)
		self.Pass_Browse.config(relief = FLAT, state= DISABLED)
		self.Hash_Browse.config(relief = FLAT, state = DISABLED)
		self.Run_Button.config(relief = FLAT, state = DISABLED)
		self.Hash_Entry.config(state = DISABLED)
		self.Pass_Entry.config(state = DISABLED)
		self.Write_File.config(state = DISABLED)

	# ------------ WAITS FOR USER ------------ #
	def Wait(self):

		self.Clear_Button.config(state = NORMAL, relief = RAISED)	# ENABLES THE CLEAR BUTTON

	# ------------ CLEANUP BEFORE CLOSING, QUIT ------------ #
	def closing(self):

    		if askokcancel("QUIT?", "Do you want to Quit?") == True:	# POPUP ASKS USER I THEY ARE SURE THEY WANT TO QUIT
			if self.write.get() == 1 and self.Run_Open.get() == 1:	# IF USER WRITES TO FILE AD OPENED FILE
				target.close()					# CLOSE FILE PROGRAM WROTE TO
			if self.Open == 1:					# IF PROGRAM READ FROM HASH LIST
				text.close()					# CLOSES THE HASH LIST FILE PROGRAM READ FROM
			self.root.destroy()					# DESTORYS THE GUI
			sys.exit()						# STOPS ALL BACKGROUND PROCCESSES

# ------------------------------------------------------------------------------------------------ #
# ------------------------------------------ MAIN CALL ------------------------------------------- #
# ------------------------------------------------------------------------------------------------ #

Main()						
						 
