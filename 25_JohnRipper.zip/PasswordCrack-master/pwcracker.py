
#!/usr/bin/python
import hashlib

hash = "2b2c0628ab500751ff6701dd8789d331"
wordlist = "rockyou.txt"

num = 0

for line in open(wordlist, "r"):
    line = line.replace("\n", "")

    num = num + 1

    if hashlib.md5(line).hexdigest() == hash:
        print "WOO! Got one on line " + str(num) + ". The password is: " + line
        quit(