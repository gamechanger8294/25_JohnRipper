# ------------ PWCRACKER1.PY ------------ #
# READS HASHES FROM LIST ("UNSALTED_HASHES.TXT)
# PROMPTS USER IF THEY'D LIKE TO CONTINUE AFTER EACH HASH

# ------------ IMPORTS ------------ #
import hashlib			# NEEDED TO DO THE "HASH" WORK

# ------------ HARDCODED FILES ------------ #
wordlist = "rockyou.txt"					# HARDCODED PASSWORD DICTIONARY FILE
hashlist = "unsalted-hashes.txt"				# HARDCODED HASH LIST FILE

# ----------------------------------- #
# ------------ FUNCTIONS ------------ #
# ----------------------------------- #

# ------------ CONTINUE PROMPT ------------ #
def Continue():
	cont = raw_input("Continue?[Y/n]: ")			# PROMPTS USER TO CONTINUE
	if cont == "Y" or cont == "y":				# "YES" OPTION			
		print "\n"					# PRINTS NEWLINE SO IT LOOKS "PRETTY"
		return True					# ONLY RETURN VALUE, RETURNS TRUE IF THE USER WANTS TO CONTINUE

	elif cont == "n" or cont == "N":			# "NO" OPTION
		print "\n"					# PRINTS NEWLINE SO IT LOOKS "PRETTY"
		quit()						# THIS QUITS THE PROGRAM

	else:							# DOESN'T MAKE SURE THERE'S ONLY VALID INPUT, CONTINUES IF NOT "Y" OR "N"
		print "Invalid Input. Continuing . . . \n"
		return True					# FUNCTION BASICALLY RETURNS TRUE, UNLESS USER ENTER "N"

# ------------ SEARCH LOOP ------------ #
def searchlist(Hash, num):					# FUNCTION HAS TWO PARAMETERS: THE HASH TO SEARCH FOR, AND LINE NUMBER
	for line in open(wordlist, "r"):			# WILL READ IN ONE LINE OF FILE AND SAVE IT TO LINE, UNTIL eof
		line = line.replace("\n", "")			# REMOVES NEWLINE CHARACTERS FROM THE HASH READ FROM FILE

		num = num + 1					# INCREMENTS THE NUM COUNTER (CURRENT LINE COUNT)

		if hashlib.md5(line).hexdigest() == Hash:	# COMPARES THE HASH TO THE PASSWORD FROM FILE, IF EQUAL CONTINUES THE CODE BELOW
			print "WOO! Got one on line " + str(num) + ". The password is: " + line 
			if Continue() == True:			# CALLS THE CONTINUE FUNCTION, IF TRUE, RETURNS AND CONTINUES OTHERWISE QUITS
				return				# RETURNS TO SEARCH FOR NEXT HASH'S PASSWORD IN "MAIN"

	print "No Password Found!"				# PRINTS THIS IF IT GETS THROUGH THE WHOLE FOR LOOP WITHOUT FINDING A PASSWORD
	if Continue() == True:					# SEES IF THE USER WOULD LIKE TO CONTINUE
		return						# RETURNS TO SEARCH FOR NEXT HASH'S PASSWORD IN "MAIN"
		
# -------------------------------- #
# ------------ "MAIN" ------------ #
# -------------------------------- #

for Hash in open(hashlist, "r"):				# READS IN ONE FILE FROM THE HASHLIST FILE AND SAVES IT TO HASH UNTIL EOF
	Hash = Hash.replace("\n", "")				# REMOVES NEWLINE CHARACTERS FROM THE HASH

	print "Hash: " + Hash					# PRINTS THE CURRENT HASH THE PROGRAM IS SEARCHING FOR

	num = 0							# MAKES SURE NUM ALWAYS STARTS AT ZERO
	searchlist(Hash, num)					# CALLS THE SEARCHLIST FUNCTION WITH THE PARAMTERS NEEDED IN HOPES OF FINDING PASSWORD

