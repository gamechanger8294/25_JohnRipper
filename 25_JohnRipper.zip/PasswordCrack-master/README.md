# PasswordCrack (UPDATED 06/16/17)
A Simple Python Password Cracker and Modifications

### Implemented Features: 
* Prompts user to enter a Hash List File or a Single Hash  
* Prompts user if they'd like to write to file or not  
* Let's user type in their own files (will need to type in full path if not in the same directory)  
* Implements error handling for invlaid files for both hash list files and password list files as well as checks for valid hash entries  
* Asks user if they'd like to continue after the result for a hash is found

### Final Files:
(Note: all of these files were written and tested using a Linux VM, can't guarantee all files run perfectly elsewhere)  
* pwcracker5.py - includes all of the implemented features, but runs in terminal  
* pwcracker6.py - includes all of the implemented features in a GUI (You will need to install TkInter to run this code or use final)  
* final - Standalone Linux Executable file for **pwcracker6.py**

### Files:
1. **pwcracker.py**  
   This is the original password cracker, I had no part in writing this and was just given it as a reference. I was expected to build off of it and make it better with each new verison.

2. **pwcracker1.py (Fully Commented)**  
   This updated version reads a hashed password from the list file **unsalted-hashes.txt**. It reads one hash at a time and then searches to see if it can find a match with **rockyou.txt**. After reading one hash and searching, It prompts the user if they'd like to continue or not.

3. **pwcracker2.py (Fully Commented)**  
   This updated version asks the user to input the name of the files they would like to read from. Because of this, I also added error handling to make sure the user enters valid input and that an entered file exists or isn't empty.

5. **pwcracker3.py (Fully Commented)**  
   This version allows the user to choose between entering a single hash or reading hashes from a list file.

6. **pwcracker4.py**  
   This version fundamentally does the exact same thing as **pwcracker3.py**, but I built a GUI. I used **TkInter** and had to rework some of the functions so that they would work correctly. This is not a final product and there's some bugs I worked out later for the final **pwcracker6.py**.

   To run the code for this you will need to install TkInter, this can be done using the command line: `sudo apt-get install python-tk`

7. **pwcracker5.py (Fully Commented)**  
   This version was built off of **pwcracker3.py**. It asks the user if they would like to write to a file or not, if they choose to it rights the results to **Results.txt**. I plan on implementing this in the GUI (building it off of **pwcracker4.py**) too, and that is now present in **pwcracker6.py**.

8. **pwcracker6.py (Fully Commented)**  
   This version was built off of **pwcracker4.py** and included the same write to file feature found in **pwcracker5.py**. I also reworked the GUI's layout and fixed most of the bugs from the previous version.

   To run the code for this you will need to install TkInter, this can be done using the command line: `sudo apt-get install python-tk`

9. **final (Standalone Linux Executable)**  
   Ths is the final version. It is a Linux executable and will only work in Linux environments. I used **pyinstaller** to make the executable and I am not sure if this is the best module to use and will continue looking.
    

