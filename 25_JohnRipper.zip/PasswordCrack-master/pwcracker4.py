

# ------------------------------------------------------------------------------------------------
# ------------------------------------------- IMPORTS --------------------------------------------
# ------------------------------------------------------------------------------------------------

from Tkinter import *				# Used for the GUI
from tkMessageBox import *			# Allows Popups
import hashlib					# Needed for the Hash Work
import os					# Needed for File Error Handling
import csv					# Needed for File Explorer
from tkFileDialog import askopenfilename	# Needed for File Explorer

# ------------------------------------------------------------------------------------------------
# --------------------------------------- SETS UP THE GUI ----------------------------------------
# ------------------------------------------------------------------------------------------------

class Main:					

	def __init__(self, root):

		# ------------ Hash Options Section ------------
		optionsframe = LabelFrame(root, text=" Hash Options ", labelanchor=NW)
		optionsframe.pack(side=TOP, fill=X)

		self.option2 = Radiobutton(optionsframe, text="Single Hash", value=1)
		self.option2.grid(row=0, column=1, padx=5, pady=5)
		self.option2.bind('<Button-1>', self.SingleHash)

		self.option1 = Radiobutton(optionsframe, text="From List", value=2)
		self.option1.grid(row=0, column=0, padx=5, pady=5)
		self.option1.bind('<Button-1>', self.HashList)

		# ------------ User Input Section ------------
		inputs = LabelFrame(root, text=" User Inputs ", labelanchor=NW)
		inputs.pack(side=TOP, fill=X)
		
		self.Hashlabel = Label(inputs, textvariable=HashLabel)
		self.Hashlabel.grid(row=0, column=0, padx=5, pady=5)
		self.HashEntry = Entry(inputs)
		self.HashEntry.grid(row=0, column=1, padx=5, pady=5)

		self.HashBrowse = Button(inputs, textvariable=Browse)
		self.HashBrowse.grid(row=0, column=2, padx=5, pady=5)
		self.HashBrowse.bind('<Button-1>', self.BrowseHash)

		Label(inputs, text="Password List: ").grid(row=1, column=0, padx=5, pady=5)
		self.PassEntry = Entry(inputs)
		self.PassEntry.grid(row=1, column=1, padx=5, pady=5)

		self.PassBrowse = Button(inputs, text="Browse...")
		self.PassBrowse.grid(row=1, column=2, padx=5, pady=5)
		self.PassBrowse.bind('<Button-1>', self.BrowsePass)

		# ------------ Run, Clear Button Section ------------
		run = Frame(root)
		run.pack(side=TOP, fill=X)

		self.runbut = Button(run, text="Run")
		self.runbut.grid(row=0, column=0, padx=5, pady=5)
		self.runbut.bind('<Button-1>', self.RunProgram)

		self.clearbut = Button(run, text="Clear")
		self.clearbut.grid(row=0, column=1, padx=5, pady=5)
		self.clearbut.bind('<Button-1>', self.ClearInputs)

		Label(run, textvariable=RunLab).grid(row=0, column=2, padx=5, pady=5)

		# ------------ Result Section ------------
		results = LabelFrame(root, text=" Results ", labelanchor=NW)
		results.pack(side=TOP, fill=X)

		Label(results, text="Hash: ").pack(side=TOP, fill=X)
		Label(results, textvariable=Hash).pack(side=TOP, fill=X)
		Label(results, text="").pack(side=TOP, fill=X)		
		Label(results, text="Result: ").pack(side=TOP, fill=X)
		Label(results, textvariable=Result).pack(side=TOP, fill=X)
		Label(results, text="").pack(side=TOP, fill=X)		

		# ------------ Continue, Quit Buttons ------------
		ContOptions = Frame(root)
		ContOptions.pack(side=TOP, fill=X)

		self.Cont = Button(ContOptions, text="Continue")
		self.Cont.grid(row=0, column=1, padx=5, pady=5)
		self.Cont.bind('<Button-1>', self.Continue)
		self.Cont.config(relief = FLAT, state=DISABLED)

		self.quit = Button(ContOptions, text="Quit")
		self.quit.grid(row=0, column=2, padx=5, pady=5)
		self.quit.bind('<Button-1>', self.Quit)

		# ------------ Status Bar Section ------------
		current = Frame(root)
		current.pack(side=BOTTOM, fill=X)

		Label(current, textvariable=Status, bd=1, relief=SUNKEN).pack(side=TOP, fill=X)

# ------------------------------------------------------------------------------------------------
# ------------------------------------------ FUNCTIONS -------------------------------------------
# ------------------------------------------------------------------------------------------------

	# ------------ "Main" Logic Loop ------------
	def RunProgram(self, event):

		RunLab.set("Running...")
		global PassList
		PassList = str(self.PassEntry.get())
		global HashList
		HashList = str(self.HashEntry.get())
		PasswordFound = False

		if self.FileExists(PassList) == True and self.FileEmpty(PassList) == True:

			if self.Hashlabel.cget("text") == "Hash List: ":
				if self.FileExists(HashList) == True and self.FileEmpty(HashList) == True:
					global text
					text = open(HashList, "r")
					Status.set("RUNNING: Hash List...")	
					self.SrchHashList()
			else:
				if self.HashCheck(HashList) == True:
					Status.set("RUNNING: Single Hash...")
					self.SrchSingleHash()
					
	# ------------ Single Hash Search Loop ------------
	def SrchSingleHash(self):
		PasswordFound = False
		self.option1.config(state = DISABLED)
		self.option2.config(state = DISABLED)
		self.clearbut.config(relief = FLAT, state = DISABLED)
		self.PassBrowse.config(relief = FLAT, state= DISABLED)
		HashIn = HashList.replace("\n", "")
		Hash.set(HashIn)
		num = 0
		for line in open(PassList, "r"):
			line = line.replace("\n", "")
			num = num + 1
			Status.set("TESTING (" + str(num) +"): " + line)				
			root.update()
			if hashlib.md5(line).hexdigest() == HashIn:
				Result.set("WOO! Got one on line " + str(num) + "\n The password is: " + line)
				Status.set("PASSWORD FOUND! Waiting...")
				PasswordFound = True
				break
		if PasswordFound == False:
			Result.set("No Password Found")
			Status.set("END OF FILE! NO PASSWORD FOUND...")
		self.Cont.config(relief = RAISED, state=NORMAL)
		self.Wait()

	# ------------ HashList Search Loop ------------
	def SrchHashList(self):
		PasswordFound = False
		self.option1.config(state = DISABLED)
		self.option2.config(state = DISABLED)
		self.clearbut.config(relief = FLAT, state = DISABLED)
		self.PassBrowse.config(relief = FLAT, state= DISABLED)
		self.HashBrowse.config(relief = FLAT, state = DISABLED)
		HashIn = text.readline().replace("\n", "")
		if HashIn == "":
			Status.set("END OF HASH LIST FILE! Waiting...")
			Result.set("RESULTS WILL GO HERE!")
			Hash.set("HASH WILL GO HERE!")
			self.HashEntry.delete(0, "end")
			self.Cont.config(relief = FLAT, state=DISABLED)
			self.Wait()
		else:
			Hash.set(HashIn)
			num = 0
			root.update()		
			for line in open(PassList, "r"):
				line = line.replace("\n", "")
				num = num + 1
				Status.set("TESTING (" + str(num) +"): " + line)
				root.update()
				if hashlib.md5(line).hexdigest() == HashIn:
					Result.set("WOO! Got one on line " + str(num) + "\n The password is: " + line)
					Status.set("PASSWORD FOUND! Waiting...")
					PasswordFound = True
					break
			if PasswordFound == False:	
				Result.set("NO Password Found")
				Status.set("END OF FILE! NO PASSWORD FOUND...")
			self.Cont.config(relief = RAISED, state=NORMAL)
			self.Wait()

	# ------------ Sets up Single Hash Options ------------
	def SingleHash(self, event):
		self.HashBrowse.config(relief = FLAT, state = DISABLED)
		Status.set("LOADING: Single Hash Options...")
		HashLabel.set("Hash: ")
		Browse.set("")

	# ------------ Sets up Hashed List Options ------------
	def HashList(self, event):
		Status.set("LOADING: Hash List Options...")
		HashLabel.set("Hash List: ")
		Browse.set("Browse...")
		self.HashBrowse.config(relief = RAISED, state = NORMAL)

	# ------------ Quits Program ------------
	def Quit(self, event):
		quit()

	# ------------ Continues Program ------------
	def Continue(self, event):
		PasswordFound = False
		if self.Hashlabel.cget("text") == "Hash List: ":
			RunLab.set("Running...")
			Result.set("")
			self.Cont.config(relief = FLAT, state=DISABLED)
			self.SrchHashList()
		else:
			self.HashEntry.delete(0, "end")
			Status.set("Enter A New Hash...")
			Hash.set("HASH WILL GO HERE!")
			Result.set("RESULTS WILL GO HERE!")
			self.Cont.config(relief = FLAT, state=DISABLED)
		
	# ------------ Clears All Inputs ------------	
	def ClearInputs(self, event):
		Status.set("Clearing . . .")
		self.HashEntry.delete(0, "end")
		self.PassEntry.delete(0, "end")
		Hash.set("HASH WILL GO HERE!")
		Result.set("RESULTS WILL GO HERE!")
		self.Cont.config(relief = FLAT, state = DISABLED)

	# ------------ Allows User to Browse for Password File ------------
	def BrowsePass(self, event):
		Status.set("Browsing for Password List File...")
		Tk().withdraw() 
		PassList = askopenfilename()
		self.PassEntry.delete(0, "end")
		self.PassEntry.insert(0, PassList)

	# ------------ Allows User to Browse for Hash List File ------------
	def BrowseHash(self, event):
		Status.set("Browsing for Hash List File...")
		Tk().withdraw()
		HashIn = askopenfilename()
		self.HashEntry.delete(0, "end")
		self.HashEntry.insert(0, HashIn)
	
	# ------------ Test for Valid Hash ------------
	def HashCheck(self, Hash): 
		if len(Hash) != 32:
			showerror("ERROR!", "ERROR: Invalid Hash.")
			Status.set("ERROR! FIX TO CONTINUE...")
			self.Wait()
		else:
			return True

	# ------------ Checks That File Exists ------------
	def FileExists(self, file):
		if os.path.isfile(file) == False:
			showerror( "ERROR!","ERROR: File (" + file + ") Doesn't Exist.")
			Status.set("ERROR! FIX TO CONTINUE...")
			self.Wait()
		else:
			return True

	# ------------ Checks That File Isn't Empty ------------
	def FileEmpty(self, file):
		if os.path.getsize(file) == 0:
			showerror("ERROR!","ERROR: File (" + file + ") Is Empty.")
			Status.set("ERROR! FIX TO CONTINUE...")
			self.Wait()
		else:
			return True

	# ------------ Waits for User to Click a Button ------------
	def Wait(self):
		RunLab.set("")
		Waiting.set("")
		self.option1.config(state = NORMAL)
		self.option2.config(state = NORMAL)
		self.clearbut.config(state = NORMAL, relief = RAISED)
		self.HashBrowse.config(state = NORMAL, relief = RAISED)
		self.PassBrowse.config(state = NORMAL, relief = RAISED)

# ------------------------------------------------------------------------------------------------
# -------------------------------- INITIALIZES VALUES AND PROGRAM --------------------------------
# ------------------------------------------------------------------------------------------------

# ------------ Sets Up Main GUI Loop ------------
root = Tk()						
root.title("Password Cracker GUI")			# Renames the GUI Window
#img = PhotoImage(file = r'Andre.png')			# Used for the Icon Image
#root.tk.call('wm', 'iconphoto', root._w, img)		# Sets the Icon Image

# ------------ Initialize Values ------------
HashLabel = StringVar()
HashLabel.set("Hash List: ")

Status = StringVar()
Status.set("STATUS WILL GO HERE!")

Hash = StringVar()
Hash.set("HASH WILL GO HERE!")

Result = StringVar()
Result.set("RESULTS WILL GO HERE!")

Browse = StringVar()
Browse.set("Browse...")

Waiting = StringVar()
Waiting.set("")

RunLab = StringVar()
RunLab.set("")

# ------------ Calls ------------
Main(root)						
root.mainloop()						 
		
