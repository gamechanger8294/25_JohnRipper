# ------------ PWCRACKER5.PY ------------ #
# ALLOWS USERS TO WRITE TO FILE (RESULTS.TXT)

# ------------ IMPORTS ------------ #
import hashlib		# USED TO DO THE HASH WORK
import os		# USED TO CHECK VALIDITY OF FILES

# ------------ SETUPS SINGLE HASH OR HASH LIST OPTIONS ------------ #
def setup():		# THIS FUNCTION ACTS AS OUR MAIN
	setup = raw_input("Pick One Of The Following:\na) Hashed Password File\nb) Single Password Hash\nq) Quit\nYour Choice: ")	# PROMPTS USER FOR HASH CHOICES
	while (setup != "a" and setup != "b" and setup != "q"):		# MAKES SURE USER ENTERS VALID INPUT
		print "ERROR: Invalid Input. Try Again . . ."		# LETS THE USER KNOW THEY DIDN;T ENTER THE RIGHT INPUT
		setup = raw_input("Pick One Of The Following:\na) Hashed Password File\nb) Single Password Hash\nYour Choice: ")	# PROMPTS USER FOR HASH CHOICES AGAIN
	if setup == "a":				# "A" OPTION IS THE HASHED LIST FILE
		print "\nHashed Password File . . .\n"
		hash_file()				# CALLS HASH FILE SETUP
	elif setup == "b":				# "B" OPTION IS THE SINGLE HASH OPTION
		print "\nSingle Password Hash . . .\n"
		single_hash()				# CALLS SINGLE HASH SETUP
	else:						# "Q" IS THE QUIT OPTION
		print "\nQuitting . . ."
		quit()					# QUITS PROGRAM	

# ------------ READS FROM HASH LIST FILE ------------ #
def hash_file():
	global write								# VARIABLE TO HOLD IF USER WANTS TO WRITE TO FILE
	write = False								# STARTS ON FALSE
	fileprompt = raw_input("Write Results to File?[Y/n]: ")			# PROMPTS USER IF THEY'D LIKE TO WRITE TO FILE
	while (fileprompt != "Y" and fileprompt != "y" and fileprompt != "N" and fileprompt != "n"):	# MAKES SURE ITS VALID INPUT ONLY
		print "ERROR: Invalid Input. Try Again . . ."			# PRINTS IF ERROR ENTERS WRONG INPUT
		fileprompt = raw_input("Write Results to File?[Y/n]: ")		# REPROMPTS THE USER
	if fileprompt == "y" or fileprompt == "Y":				# "YES" OPTION		
		write = True							# USER WANTS TO WRITE TO FILE, MUST CHANGE THIS VARIABLE
		global target							# THE FILE TO BE WRITTEN TO, GLOBAL SO ANY FUNCTION CAN USE
		target = open("Results.txt", "wb")				# OPENS THE FILE TO WRITE TO
		print"Writing to file 'Results.txt' . . .\n"			# LET'S USER KNOW WRITING TO FILE

	hashlist = raw_input("Enter Your Hashed List File: ") 			# PROMPTS USER FOR THE HASHED LIST FILE
	hashlist = hashlist.replace("\n", "")					# REMOVES NEWLINE CHARACTERS
	wordlist = raw_input("Enter Your Password List File: ")			# PROMPTS USER FOR THE PASSWORD FILE
	wordlist = wordlist.replace("\n", "")					# REMOVES NEWLINE CHARACTERS

	error(hashlist, wordlist)						# CHECKS TO MAKE SURE FILES ARE VALID

	print "\nRunning . . .\n"

	if write == True:								
		target.write("Hashed List File: " + hashlist + "\nPassword File: " + wordlist + "\n")	# PRINTS FILE NAMES TO THE TARGET FILE	

	for Hash in open(hashlist, "r"):				# READS IN THE FIRST HASH FROM THE HASHLIST AND SAVES TO HASH
		Hash = Hash.replace("\n", "")				# REMOVES NEWLINE CHARACTERS
		print "Hash: " + Hash					# PRINTS THE CURRENT HASH
		if write == True:					
			target.write("\nHash: " + Hash)			# WRITES HASH TO FILE ONLY IF USER WANTS TO WRITE TO FILE
		num = 0							# MAKE SURE NUM STARTS AT 0
		searchlist(Hash, num, wordlist)				# SEARCHES FOR THE HASH

	print "End Of File, Quitting . . ."				# REACHED THE END OF THE HASHED LIST FILE
	quit()								# QUITS THE PROGRAM

# ------------ HASH LIST SEARCH LOOP ------------ #
def searchlist(Hash, num, wordlist):				
	for line in open(wordlist, "r"):								# OPENS THE PASSWORD FILE AND READS ONE LINE
		line = line.replace("\n", "")								# REPLACES NEWLINE CHARACTERS

		num = num + 1										# INCREMENTS THE NUMBER COUNTER (NUMBER LINE)

		if hashlib.md5(line).hexdigest() == Hash:						# COMPARES THE PASSWORD LINE TO THE HASH
			print "WOO! Got one on line " + str(num) + ". The password is: " + line 	# PRINTS THE LINE NUMBER AND PASSWORD IF FOUND
			if write == True:								
				target.write("\nPassword: " + line + "\n")				# WRITES THE RESULT TO THE FILE
			if cont() == True:								# PROMPTS USER TO CONTINUE
				return									# RETURNS IF THEY WANT TO CONT, OR QUITS

	print "Searched " + str(num) + " Passwords. No Match Found."					# GETS TO THIS IF PASSWORD ISN'T FOUND
	if write == True:
		target.write("\nSearched " + str(num) + " Passwords. No Match Found.\n")		# WRITES TO FILE
	if cont() == True:										# PROMPTS USER TO CONTINUE
		return											# RETURNS IF THEY WANT TO CONT, OR QUITS

# ------------ SEARCHES FOR SINGLE HASH ------------ #
def single_hash():
	global write											# WRITE VARIABLE TO KEEP TRACK OF WRITING TO FILE
	write = False											# WRITE WILL START AS DEFAULT
	fileprompt = raw_input("Write Results to File?[Y/n]: ")						# PROMPTS USER TO WRITE TO FILE
	while (fileprompt != "Y" and fileprompt != "y" and fileprompt != "N" and fileprompt != "n"):	# MAKES SURE USER ENTERS VALID INPUT
		print "ERROR: Invalid Input. Try Again . . ."						# USER DIDN'T ENTER OCRRECT INPUT
		fileprompt = raw_input("Write Results to File?[Y/n]: ")					# REPROMPTS USER
	if fileprompt == "y" or fileprompt == "Y":							# "YES" OPTION
		write = True										# WRITES BECOMES TRUE, BECAUSE THEY WANT TO WRITE
		global target										# TARGET IS THE FILE TO BE WRITTEN TO
		target = open("Results.txt", "wb")							# OPENS RESULTS.TXT TO WRITE TO
		print"Writing to file 'Results.txt' . . .\n"						

	Hash = raw_input("Enter A Hashed Password: ")				# PROMPTS USER FOR HASH
	Hash = Hash.replace("\n", "")						# REMOVES THE NEWLINE CHARACTER
	wordlist = raw_input("Enter Your Password List File: ")			# PROMPTS USER FOR PASSWORD FILE
	wordlist = wordlist.replace("\n", "")					# REMOVES THE NEWLINE CHARACTER

	errors(Hash, wordlist)							# MAKES SURE HASH AND WORDLIST ARE VALID

	if write == True:							
		target.write("\nPassword File: " + wordlist + "\n")		# WRITES PASSWORD FILE NAME TO FILE

	print "\nRunning . . .\n"						# LETS USER KNOW THE PROGRAM IS NOW RUNNING

	print "Hash: " + Hash							# PRINTS CURRENT HASH TO TERMINAL	
	if write == True:				
			target.write("\nHash: " + Hash)				# WRITES HASH TO FILE
	num = 0									# MAKES SURE NUMBER STARTS AT 0
	searchsingle(Hash, num, wordlist)					# CALLS SEARCH SINGLE LOOP

	while cont() == True:							# PROMPTS USER TO CONTINUE
		Hash = raw_input("Enter A Hashed Password: ")			# IF THEY'D LIKE TO CONTINUE, PROMPTS FOR NEW HASH
		Hash = Hash.replace("\n", "")					# REPLACES THE NEWLINE CHARACTER

		errors(Hash, wordlist)						# RECHECKS THE NEW HASH

		print "\nRunning . . .\n"					# LETS USER RUN

		print "Hash: " + Hash						# UPDATES HASH IN TERMINAL
		if write == True:						
			target.write("\nHash: " + Hash)				# WRITES HASH TO FILE

		num = 0								# RESETS NUM TO 0
		searchsingle(Hash, num, wordlist)				# CALLS SEARCH SINGLE

# ------------ SINGLE HASH SEARCH LOOP ------------ #
def searchsingle(Hash, num, wordlist):
	for line in open(wordlist, "r"):								# READS ONE LINE FROM PASSWORD FILE
		line = line.replace("\n", "")								# REPLACES NEWLINE CHARACTER

		num = num + 1										# INCRMENTS NUM COUNT

		if hashlib.md5(line).hexdigest() == Hash:						# COMPARES HASH TO PASSWORD LINE
			print "WOO! Got one on line " + str(num) + ". The password is: " + line 	# PRINTS IF PASSWORD IF FOUND
			if write == True:
				target.write("\nPassword: " + line + "\n")				# WRITES PASSWORD TO FILE
			return										

	print "Searched " + str(num) + " Passwords. No Match Found."					# PRINTS IF NO PASSWORD WAS FOUND
	if write == True:
		target.write("\nSearched " + str(num) + " Passwords. No Match Found.\n")		# WRITES TO FILE
	return

# ------------ PROMPTS USER TO CONTINUE ------------ #
def cont():
	cont = raw_input("Continue?[Y/n]: ")					# PROMPTS USER CONTINUE?
	while (cont != "Y" and cont != "y" and cont != "N" and cont != "n"):	# LOOPS UNTIL USER ENTER "Y' OR "N"
		print "ERROR: Invalid Input. Try Again . . ."			# LETS USER KNOW THEY ENTERED INVALID INPUT
		cont = raw_input("Continue?[Y/n]: ")				# PROMPTS USER CONTINUE AGAIN

	if cont == "Y" or cont == "y":						# USER'S "Y" OPTION			
		print "\n"							# PRINTS NEWLINE TO KEEP TERMINAL "PRETTY"
		return True							# RETURNS TRUE IF USER WANTS TO CONTINUE

	else:									# USER'S "N" OPTION
		print "\nQuitting . . . "					# LETS USER KNOW PROGRAM IS QUITtING
		quit()								# QUITS THE PROGRAM

# ------------ CHECKS IF FILE EXISTS ------------ #
def file_exists(file):							# MAKES SURE FILE EXISTS, TAKES A FILE AS A PARAMETER
	if os.path.isfile("./" + file) == False:			# CHECKS TO SEE IF FILE EXISTS
		print "ERROR: File (" + file + ") Doesn't Exist."	# LETS THE USER KNOW WHAT THE ERROR IS
		return False						# RETURNS FALSE IF FILE DOESN'T EXISTS
	return True							# RETURNS TRUE IF FILE EXISTS

# ------------ CHECK IF FILE IS EMPTY ------------ #
def file_empty(file):							# MAKES SURE FILE ISN'T EMPTY, TAKES A FILE AS A PARAMETER
	if os.path.getsize("./" + file) == 0:				# CHECKS TO MAKES SURE FILE ISN'T EMPTY
		print "ERROR: File (" + file + ") Is Empty."		# LETS THE USER KNOW WHAT THE ERROR IS
		return False						# RETURNS FALSE IF FILE IS EMPTY
	return True	

# ------------ ERROR PRINTING FOR HASH LIST ------------ #
def error(hashlist, wordlist):				# ERROR WILL TEST IF BITH FILES ARE VALID, TAKES BOTH FILES AS PARAMETERS
	print "\n"					# PRINTS NEWLINE TO KEEP TERMINAL "PRETTY"

	check1 = file_exists(hashlist)			# TESTS IF HASHLIST EXISTS, SETS CHECK1 TO TRUE OR FALSE
	check2 = file_exists(wordlist)			# TESTS IF WORDLIST EXISTS, SETS CHECK2 TO TRUE OR FALS

	if check1 == True:				# IF HASHLIST EXISTS
		check1 = file_empty(hashlist)		# CHECKS IF THE FILE IS EMPTY AND SETS CHECK1 TO TRUE OR FALSE
	
	if check2 == True:				# IF WORDLIST EXISTS
		check2 = file_empty(wordlist)		# CHECKS IF THE FILE IS EMPTY AND SETS CHECK2 TO TRUE OR FALSE
	
	if check1 == False or check2 == False:		# IF CHECK1 OR CHECK2 ARE FALSE (ONE OR BOTH OF THE FILES ARE EMPTY OR DOESNT EXIST)
		print"\nQuitting . . ."			# LETS USER KNOW PROGRAM IS QUITTING
		quit()					# QUITS PROGRAM

	return						# RETURNS ONLY IF ALL FILE ENTRYS ARE VALID

# ------------ ERROR PRINTING FOR SINGLE HASH ------------ #
def errors(Hash, wordlist):				# ERRORS WILL TEST TO MAKE SURE HASH IS VALID, TAKES HASH AND PASSWORD FILE AS PARAMETERS 
	if len(Hash) != 32:				# CHECKS TO SEE IF HASH IS 32 BITS LONG
		print "\nERROR: Invalid Hash."		# IF THIS IS FALSE, LETS USER KNOW THEY ENTERED INVALID HASH

	check1 = file_exists(wordlist)			# CHECKS TO SEE IF PASSWORD FILE EXISTS SETS CHECK1 TO TRUE OR FALSE

	if check1 == True:				# IF CHECK1 IS TRUE, FILE EXISTS, THEN WE MAKES SURE THE FILE ISN'T EMPTY
		check1 = file_empty(wordlist)		# CHECKS TO SEE IF FILE IS EMPTY SETS CHECK1 TO TRUE OR FALSE
	if check1 == False:				# IF CHECK1 IS FALSE THE FILE DOESN'T EXIST OR IS EMPTY
		print "\nQuitting . . ."
		quit()					# PROGRAM QUITS

# ------------ MAIN CALL ------------ #
setup()

